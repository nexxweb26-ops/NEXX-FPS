# NEXX FPS — Mobile Build Package

You can build the APK using only your Android phone through GitHub Actions.

1. Create a GitHub repository.
2. Upload the contents of this package to the repository (keep `.github/workflows/build.yml`).
3. Open the repository → Actions → Build NEXX FPS APK → Run workflow.
4. Wait for the build to finish.
5. Open the completed workflow run and download the `NEXX-FPS-debug-APK` artifact.
6. Extract the artifact ZIP and install `app-debug.apk` on your phone.

GitHub Actions performs the actual Android build on a GitHub-hosted runner, so Android Studio is not required on your phone.

package com.nexx.fps

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.TrafficStats
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.util.Locale
import kotlin.math.max

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var overlay: LinearLayout
    private lateinit var fpsText: TextView
    private lateinit var pingText: TextView
    private lateinit var downText: TextView
    private lateinit var upText: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var lastRx = TrafficStats.getTotalRxBytes()
    private var lastTx = TrafficStats.getTotalTxBytes()
    private var lastTime = SystemClock.elapsedRealtime()

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(77, notification())
        if (Settings.canDrawOverlays(this)) showOverlay()
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            background = getDrawable(R.drawable.bg_overlay)
            alpha = 0.92f
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        fpsText = metric("FPS", "60")
        pingText = metric("PING", "32 ms")
        row.addView(fpsText)
        addDivider(row)
        row.addView(pingText)
        overlay.addView(row)

        val net = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        downText = metric("↓", "12.4 Mbps")
        upText = metric("↑", "2.1 Mbps")
        net.addView(downText)
        net.addView(Space(this), LinearLayout.LayoutParams(12, 1))
        net.addView(upText)
        overlay.addView(net)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 12
            y = 36
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0

        overlay.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    wm.updateViewLayout(overlay, params)
                    true
                }
                else -> true
            }
        }

        wm.addView(overlay, params)
        tick()
    }

    private fun metric(label: String, value: String): TextView =
        TextView(this).apply {
            text = "$label  $value"
            textSize = 12f
            setTextColor(Color.WHITE)
            setPadding(4, 2, 4, 2)
        }

    private fun addDivider(parent: LinearLayout) {
        val d = View(this).apply { setBackgroundColor(Color.rgb(100, 30, 45)) }
        parent.addView(d, LinearLayout.LayoutParams(1, 30))
    }

    private fun tick() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                updateNetwork()
                handler.postDelayed(this, 1000)
            }
        }, 1000)
    }

    private fun updateNetwork() {
        val now = SystemClock.elapsedRealtime()
        val dt = max(1L, now - lastTime)
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()

        val downMbps = ((rx - lastRx) * 8.0 / dt / 1000.0)
        val upMbps = ((tx - lastTx) * 8.0 / dt / 1000.0)

        downText.text = "↓  ${formatSpeed(downMbps)} Mbps"
        upText.text = "↑  ${formatSpeed(upMbps)} Mbps"

        lastRx = rx
        lastTx = tx
        lastTime = now
    }

    private fun formatSpeed(v: Double): String =
        String.format(Locale.US, "%.1f", v)

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "nexx_fps",
                "NEXX FPS Monitoring",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "nexx_fps") else Notification.Builder(this)
        return builder
            .setContentTitle("NEXX FPS")
            .setContentText("Gaming overlay is running")
            .setSmallIcon(R.drawable.ic_nexx)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::overlay.isInitialized) {
            try { wm.removeView(overlay) } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

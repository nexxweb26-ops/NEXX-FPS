package com.nexx.fps

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private val red = Color.rgb(255, 23, 68)
    private val bg = Color.rgb(8, 8, 8)
    private val card = Color.rgb(18, 18, 18)
    private val white = Color.rgb(245, 245, 245)
    private val muted = Color.rgb(158, 158, 158)
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestNotificationPermission()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 28, 20, 28)
            setBackgroundColor(bg)
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "NEXX FPS"
            textSize = 34f
            setTextColor(white)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "Gaming Performance Monitor"
            textSize = 15f
            setTextColor(muted)
        }
        root.addView(sub, lp(0, 0, 0, 22))

        status = TextView(this).apply {
            text = "● Monitoring: Ready"
            textSize = 14f
            setTextColor(Color.rgb(57, 230, 107))
            setPadding(16, 14, 16, 14)
            background = getDrawable(R.drawable.bg_card)
        }
        root.addView(status, lp(0, 0, 0, 14))

        addMetric(root, "FPS Monitor", "60 FPS", "Display/overlay metric")
        addMetric(root, "Network Speed", "↓ 12.4 Mbps   ↑ 2.1 Mbps", "Estimated from device traffic")
        addMetric(root, "Ping / Latency", "32 ms", "Network latency")
        addMetric(root, "RAM Usage", "62%", "System memory")
        addMetric(root, "Temperature", "—", "Not exposed reliably on all Android devices")
        addMetric(root, "Battery", "${batteryPercent()}%", "Current battery level")

        val start = Button(this).apply {
            text = "START OVERLAY"
            textSize = 17f
            setTextColor(Color.WHITE)
            background = getDrawable(R.drawable.bg_button)
            setPadding(20, 18, 20, 18)
            setOnClickListener { startOverlayFlow() }
        }
        root.addView(start, lp(0, 0, 0, 12))

        val note = TextView(this).apply {
            text = "The floating HUD requires Android's Draw over other apps permission. Exact in-game FPS is only available where Android/game APIs expose it."
            textSize = 12f
            setTextColor(muted)
            setPadding(12, 8, 12, 8)
        }
        root.addView(note)

        setContentView(scroll)
    }

    private fun addMetric(parent: LinearLayout, name: String, value: String, hint: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(R.drawable.bg_card)
            setPadding(16, 14, 16, 14)
        }
        val n = TextView(this).apply {
            text = name
            textSize = 14f
            setTextColor(white)
        }
        val v = TextView(this).apply {
            text = value
            textSize = 25f
            setTextColor(red)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val h = TextView(this).apply {
            text = hint
            textSize = 11f
            setTextColor(muted)
        }
        box.addView(n)
        box.addView(v)
        box.addView(h)
        parent.addView(box, lp(0, 0, 0, 10))
    }

    private fun startOverlayFlow() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            Toast.makeText(this, "Allow NEXX FPS to display over other apps", Toast.LENGTH_LONG).show()
            return
        }

        val intent = Intent(this, OverlayService::class.java)
        ContextCompat.startForegroundService(this, intent)
        status.text = "● Monitoring: Active  •  Overlay Running"
        status.setTextColor(Color.rgb(57, 230, 107))
        Toast.makeText(this, "NEXX FPS overlay started", Toast.LENGTH_SHORT).show()
    }

    private fun batteryPercent(): Int {
        val bm = getSystemService(BATTERY_SERVICE) as android.os.BatteryManager
        return bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun lp(l: Int, t: Int, r: Int, b: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(l, t, r, b)
        }
}

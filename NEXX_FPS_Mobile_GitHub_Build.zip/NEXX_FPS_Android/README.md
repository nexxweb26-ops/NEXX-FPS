# NEXX FPS

Premium red/black Android gaming-performance overlay starter.

## Features
- Floating overlay using Android Draw Over Other Apps permission
- Draggable HUD
- FPS/PING display UI
- Network download/upload estimate using TrafficStats
- Foreground service + persistent notification
- Dark AMOLED-style dashboard
- Modern Android target

## Important limitation
Android does not provide a universal API for reading the exact internal FPS of every game. The `60 FPS` value in this starter is a UI placeholder/display metric, not a claim of exact in-game FPS. A production implementation should only show exact game FPS when a supported API/game integration provides it.

Temperature is also not universally exposed on Android devices.

## Build
Open this folder in Android Studio and let Gradle sync. Build:
Build > Generate App Bundles or APKs > Generate APKs.

Minimum SDK: 26
Target SDK: 35

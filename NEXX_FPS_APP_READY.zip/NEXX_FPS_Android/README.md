# NEXX FPS Android App

NEXX FPS is a dark red/black gaming overlay app with ON/OFF controls and a custom raven app icon.

## GitHub Actions

Upload this project to your repository. Keep `.github/workflows/build.yml` from the mobile build package. Then open **Actions → Build NEXX FPS APK → Run workflow**.

The workflow builds `app-debug.apk` and uploads it as the `NEXX-FPS-debug-APK` artifact.

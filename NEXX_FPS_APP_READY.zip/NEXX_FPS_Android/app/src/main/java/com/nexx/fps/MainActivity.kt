package com.nexx.fps

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private val red = Color.rgb(255, 38, 61)
    private val bg = Color.rgb(7, 7, 7)
    private val card = Color.rgb(20, 20, 20)
    private val white = Color.rgb(247, 247, 247)
    private val muted = Color.rgb(153, 153, 153)
    private val green = Color.rgb(53, 230, 107)
    private lateinit var status: TextView
    private lateinit var onButton: Button
    private lateinit var offButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestNotificationPermission()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized && Settings.canDrawOverlays(this)) {
            val running = getPreferences(MODE_PRIVATE).getBoolean("overlay_on", false)
            setUiState(running)
        }
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 28)
            setBackgroundColor(bg)
        }
        scroll.addView(root)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.nexx_icon)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        header.addView(icon, LinearLayout.LayoutParams(72, 72))
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 0, 0, 0)
        }
        val title = TextView(this).apply {
            text = "NEXX FPS"
            textSize = 30f
            setTextColor(white)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val sub = TextView(this).apply {
            text = "Gaming Performance Overlay"
            textSize = 13f
            setTextColor(muted)
        }
        titles.addView(title)
        titles.addView(sub)
        header.addView(titles)
        root.addView(header, lp(0, 0, 0, 22))

        status = TextView(this).apply {
            text = "●  OFFLINE"
            textSize = 15f
            setTextColor(muted)
            setGravity(Gravity.CENTER_VERTICAL)
            setPadding(18, 16, 18, 16)
            background = getDrawable(R.drawable.bg_card)
        }
        root.addView(status, lp(0, 0, 0, 16))

        val toggleTitle = TextView(this).apply {
            text = "OVERLAY CONTROL"
            textSize = 12f
            setTextColor(muted)
        }
        root.addView(toggleTitle, lp(0, 0, 0, 8))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        onButton = Button(this).apply {
            text = "ON"
            textSize = 16f
            setTextColor(Color.WHITE)
            background = getDrawable(R.drawable.bg_button_on)
            isAllCaps = false
            setOnClickListener { startOverlayFlow() }
        }
        offButton = Button(this).apply {
            text = "OFF"
            textSize = 16f
            setTextColor(Color.WHITE)
            background = getDrawable(R.drawable.bg_button_off)
            isAllCaps = false
            setOnClickListener { stopOverlay() }
        }
        buttons.addView(onButton, LinearLayout.LayoutParams(0, 58, 1f).apply { setMargins(0, 0, 7, 0) })
        buttons.addView(offButton, LinearLayout.LayoutParams(0, 58, 1f).apply { setMargins(7, 0, 0, 0) })
        root.addView(buttons, lp(0, 0, 0, 20))

        addMetric(root, "FPS", "60", "Overlay display value")
        addMetric(root, "PING", "32 ms", "Network latency estimate")
        addMetric(root, "RAM", "Monitoring", "System memory")
        addMetric(root, "NETWORK", "↓ / ↑", "Live traffic speed")

        val note = TextView(this).apply {
            text = "ON starts the floating HUD. OFF stops it. Android requires Display over other apps permission for the HUD."
            textSize = 12f
            setTextColor(muted)
            setPadding(8, 12, 8, 8)
        }
        root.addView(note)

        setContentView(scroll)
        setUiState(getPreferences(MODE_PRIVATE).getBoolean("overlay_on", false))
    }

    private fun addMetric(parent: LinearLayout, name: String, value: String, hint: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(R.drawable.bg_card)
            setPadding(16, 13, 16, 13)
        }
        val n = TextView(this).apply { text = name; textSize = 13f; setTextColor(white) }
        val v = TextView(this).apply {
            text = value; textSize = 24f; setTextColor(red)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val h = TextView(this).apply { text = hint; textSize = 11f; setTextColor(muted) }
        box.addView(n); box.addView(v); box.addView(h)
        parent.addView(box, lp(0, 0, 0, 10))
    }

    private fun startOverlayFlow() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Allow NEXX FPS to display over other apps", Toast.LENGTH_LONG).show()
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        getPreferences(MODE_PRIVATE).edit().putBoolean("overlay_on", true).apply()
        setUiState(true)
        Toast.makeText(this, "NEXX FPS ON", Toast.LENGTH_SHORT).show()
    }

    private fun stopOverlay() {
        stopService(Intent(this, OverlayService::class.java))
        getPreferences(MODE_PRIVATE).edit().putBoolean("overlay_on", false).apply()
        setUiState(false)
        Toast.makeText(this, "NEXX FPS OFF", Toast.LENGTH_SHORT).show()
    }

    private fun setUiState(on: Boolean) {
        if (!::status.isInitialized) return
        status.text = if (on) "●  OVERLAY ACTIVE" else "●  OFFLINE"
        status.setTextColor(if (on) green else muted)
        onButton.alpha = if (on) 1f else 0.65f
        offButton.alpha = if (on) 1f else 0.65f
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun lp(l: Int, t: Int, r: Int, b: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply { setMargins(l, t, r, b) }
}
